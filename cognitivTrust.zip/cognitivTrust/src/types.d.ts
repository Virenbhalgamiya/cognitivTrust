declare module 'vscode';
declare module 'child_process';
declare module 'path';
