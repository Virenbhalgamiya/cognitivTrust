// Dummy file to ensure TypeScript finds types for VSCode extension build
